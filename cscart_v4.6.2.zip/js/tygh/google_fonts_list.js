{
    "popular": [{
        "name": "Arimo",
        "generic-family": "sans-serif"
    }, {
        "name": "Arvo",
        "generic-family": "serif"
    }, {
        "name": "Bitter",
        "generic-family": "serif"
    }, {
        "name": "Cabin",
        "generic-family": "sans-serif"
    }, {
        "name": "Droid Sans",
        "generic-family": "sans-serif"
    }, {
        "name": "Droid Serif",
        "generic-family": "serif"
    }, {
        "name": "Fjalla One",
        "generic-family": "sans-serif"
    }, {
        "name": "Francois One",
        "generic-family": "sans-serif"
    }, {
        "name": "Lato",
        "generic-family": "sans-serif"
    }, {
        "name": "Libre Baskerville",
        "generic-family": "serif"
    }, {
        "name": "Lobster",
        "generic-family": "cursive"
    }, {
        "name": "Lora",
        "generic-family": "serif"
    }, {
        "name": "Merriweather",
        "generic-family": "serif"
    }, {
        "name": "Montserrat",
        "generic-family": "sans-serif"
    }, {
        "name": "Nunito",
        "generic-family": "serif"
    }, {
        "name": "Open Sans",
        "generic-family": "sans-serif"
    }, {
        "name": "Open Sans Condensed",
        "generic-family": "serif",
        "weight": 300
    }, {
        "name": "Oswald",
        "generic-family": "sans-serif"
    }, {
        "name": "Oxygen",
        "generic-family": "sans-serif"
    }, {
        "name": "PT Sans",
        "generic-family": "sans-serif"
    }, {
        "name": "PT Sans Narrow",
        "generic-family": "sans-serif"
    }, {
        "name": "PT Serif",
        "generic-family": "sans-serif"
    }, {
        "name": "Play",
        "generic-family": "sans-serif"
    }, {
        "name": "Raleway",
        "generic-family": "sans-serif"
    }, {
        "name": "Roboto",
        "generic-family": "sans-serif"
    }, {
        "name": "Roboto Condensed",
        "generic-family": "sans-serif"
    }, {
        "name": "Rokkitt",
        "generic-family": "serif"
    }, {
        "name": "Source Sans Pro",
        "generic-family": "sans-serif"
    }, {
        "name": "Ubuntu",
        "generic-family": "sans-serif"
    }, {
        "name": "Yanone Kaffeesatz",
        "generic-family": "sans-serif"
    }],
    "other": [{
        "name": "Abel",
        "generic-family": "sans-serif"
    }, {
        "name": "Cardo",
        "generic-family": "serif"
    }, {
        "name": "Comfortaa",
        "generic-family": "cursive"
    }, {
        "name": "Cuprum",
        "generic-family": "sans-serif"
    }, {
        "name": "Didact Gothic",
        "generic-family": "sans-serif"
    }, {
        "name": "Noto Sans",
        "generic-family": "sans-serif"
    }, {
        "name": "Noto Serif",
        "generic-family": "serif"
    }, {
        "name": "Roboto Slab",
        "generic-family": "serif"
    }, {
        "name": "Tinos",
        "generic-family": "serif"
    }, {
        "name": "Ubuntu Condensed",
        "generic-family": "sans-serif"
    }]
}